// Type dots animation
enum dotSliderAnimation { SIZE_TRANSITION, DOT_MOVEMENT }
