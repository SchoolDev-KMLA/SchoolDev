# flutter_schooldev

SchoolDev에 대한 설명 --

## 시작하기
<details><summary>개발 환경 만들기</summary>
    <div>
        <p>
    		<li> <a href="posting/start-androidstudio.html"> Android Studio 설치</a></li>
    		<li> <a href="posting/start-2.html"> Flutter플러그인 설치</a></li>
    		<li> <a href="gh-pages/start-3.md"> Firebase 설정하기</a></li>    
		</p>
    </div>
</details>





## 커스터마이즈

<details><summary>색, 사진, 아이콘 바꾸기</summary>
<p>
    <li> <a href="gh-pages/start-1.md"> Android Studio 설치</a></li>
    <li> <a href="gh-pages/start-2.md"> Flutter플러그인 설치</a></li>
    <li> <a href="gh-pages/start-3.md"> Firebase 설정하기</a></li>    
</p>
</details>

<details><summary>다른 기능 추가하기</summary>
<p>
    <li> <a href="gh-pages/start-1.md"> Android Studio 설치</a></li>
    <li> <a href="gh-pages/start-2.md"> Flutter플러그인 설치</a></li>
    <li> <a href="gh-pages/start-3.md"> Firebase 설정하기</a></li>    
</p>
</details>

## Credits

김태준

노건호 