---
layout: default
title: Start AndroidStudio
description: Install AndroidStudio
---

# Android Studio 설치하기

## 안드로이드 개발환경 만들기

먼저 안드로이드 스튜디오를 설치해야 합니다
안드로이드 스튜디오는 구글이 안드로이드 앱 개발을 위해 IntelliJ 와 함께 제작한 IDE이며 Windows, Mac, 리눅스에서 사용할 수 있습니다

![AndroidStudio](https://1.bp.blogspot.com/-cmRqES5cHbo/Wff1-YJ-vOI/AAAAAAAAxvc/yIDOMhB62TcLg5lxu9jrisz1RUZbTYAMQCLcBGAs/s1600/android-studio-logo-840x359.png)

[Android Studio 다운로드](https://developer.android.com/studio/) 
링크를 통해 사이트에 접속하면 다음과 같은 화면이 나옵니다![enter image description here](https://lh4.googleusercontent.com/PkuQz48HdVuTLRr-gGHlsJiMXgNxNAd2iYySt8mhFhRKZQoETEh7WvomUPDJDMAoWmiyt_5shzm5856rc2UPakfl57uRkdwC5hvjxdKeWyY4uW1M7awAemr1dmXZiEEJtPf1_RIA)

여기서 다운로드를 누르면 Android Studio 다운로드가 시작됩니다



다운로드후 받은 설치 파일을 실행하면  

다음과 같은 창이 보입니다

![](https://lh5.googleusercontent.com/91tFPNQr-W9FUYO1BAhva4z54vSuXrsx2rAWzEtnqtJZnI-joJXQGiwtG4lw7kVoyIXDD7LI8J5dz9pJjd6eo-3Mnu8_tX-uX3TuJLA-gLYLwIr-DQuFaltpiTwawNoDlejfuqz2)



잘 모르시겠다면 엔터를 계속 누르세요