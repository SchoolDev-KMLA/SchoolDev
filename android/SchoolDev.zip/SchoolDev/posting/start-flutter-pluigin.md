---
layout: default
title: Start AndroidStudio
description: Install AndroidStudio
---



# Flutter Plugin 설치

이제 Flutter Plugin을 Android Studio에 설치해야 합니다

Visual Studio를 사용해서 하는 방법도 있지만 여기에서는 Android Studio를 기준으로 설명하겠습니다



![](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fk.kakaocdn.net%2Fdn%2FdvAd7R%2FbtqwmDTEktr%2FKGMKlN6QXUP8xxuPmXKmt1%2Fimg.png)

Android Studio를 실행하면 다음과 같은 창이 나타납니다. 여기에서 오른쪽 하단의 Configure에서 Plugin를 선택합니다

![](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fk.kakaocdn.net%2Fdn%2FbW3cCj%2Fbtqysunl8p3%2F7QP93ONOg8tUjKdMmHsA1k%2Fimg.png)

다음과 같이 Flutter 와 Dart를 검색해서 설치합니다



![](https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fk.kakaocdn.net%2Fdn%2FcrGJSE%2Fbtqyqx6JwfI%2FHMPwwnvSBKkGk0IV89S0PK%2Fimg.png)

그러면 다음과 같이 새 Flutter  프로젝트를 시작할 수 있습니다